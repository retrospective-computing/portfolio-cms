window.CODE_MIRROR_BASE = {
  autoRefresh: true,
  lineNumbers: true,
  lineWrapping: true,
  matchBrackets: true,
  mode: 'application/json',
  rulers: [
    {
      color: '#ccf',
      column: 80,
      lineStyle: 'dashed',
    },
    {
      color: '#fcf',
      column: 100,
      lineStyle: 'dashed',
    },
    {
      color: '#ccc',
      column: 120,
      lineStyle: 'dashed',
    },
  ],
  showTrailingSpace: true,
};
window.CODE_MIRROR_READ = { ...window.CODE_MIRROR_BASE, readOnly: true };
window.CODE_MIRROR_WRITE = {
  ...window.CODE_MIRROR_BASE,
  autoCloseBrackets: true,
  gutters: ['CodeMirror-lint-markers'],
};
window.CODE_MIRROR_MERGE = {
  ...window.CODE_MIRROR_WRITE,
  collapseIdentical: false,
  connect: 'align',
  highlightDifferences: true,
  orig: '',
  origLeft: null,
  revertButtons: false,
  value: '',
};
window.diff_match_patch = require('diff-match-patch');

window.DIFF_DELETE = -1;
window.DIFF_EQUAL = 0;
window.DIFF_INSERT = 1;
window.CodeMirror = require('codemirror/lib/codemirror');
window.jsonlint = require('jsonlint-mod/web/jsonlint');
require('codemirror/mode/javascript/javascript');
require('codemirror/addon/display/autorefresh');
require('codemirror/addon/display/rulers');
require('codemirror/addon/edit/closebrackets');
require('codemirror/addon/edit/matchbrackets');
require('codemirror/addon/edit/trailingspace');
require('codemirror/addon/lint/lint');
require('codemirror/addon/lint/json-lint');
require('codemirror/addon/merge/merge');
