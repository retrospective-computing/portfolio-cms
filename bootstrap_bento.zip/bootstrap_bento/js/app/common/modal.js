/*
 * NOTICE: (c) 2015 - 2022 ConsumerInfo.com, Inc, an Experian company.
 * All Rights Reserved.
 * The material contained herein is protected by copyright and trade secret law.
 * Unauthorized use, copying, or dissemination is strictly prohibited.
 * All material contained herein is subject to Experian's confidential
 * information policies.
 * -----------------------------------------------------------------------------
 */

import { Modal as BSModal } from 'bootstrap';
import PropTypes from 'prop-types';
import React, {
  Children,
  useCallback,
  useEffect,
  useRef,
} from 'react';
import styled from 'styled-components';

export const ModalBody = ({ children }) => <div className="modal-body">{children}</div>;
ModalBody.propTypes = {
  children: PropTypes.any,
};

export const ModalFooter = ({ children, show }) => (show ? <div className="modal-footer">{children}</div> : null);
ModalFooter.propTypes = {
  children: PropTypes.any,
  show: PropTypes.bool,
};

export const ModalHeader = ({
  children,
  onClose,
  showClose,
  title,
}) => (
  <div className="modal-header">
    <h4 className="modal-title" dangerouslySetInnerHTML={{ __html: title }} />
    {children}
    {showClose ? <a aria-label="Close" className="close" data-bs-dismiss="modal" onClick={onClose} type="button"><span aria-hidden="true">×</span></a> : null}
  </div>
);
ModalHeader.propTypes = {
  children: PropTypes.any,
  onClose: PropTypes.func,
  showClose: PropTypes.bool,
  title: PropTypes.string,
};

// After ModalHeader assignment.
export const Modal = styled(({ children, className, data }) => {
  let body;
  let footer;
  let header;
  const ref = useRef();
  const timer = useRef(null);

  Children.forEach(children, (child) => {
    switch (child.type) {
      case ModalBody:
        body = child;
        break;
      case ModalFooter:
        footer = child;
        break;
      case ModalHeader:
        header = child;
        break;
      default:
      // no-op.
    }
  });

  const onHidden = useCallback(() => {
    clearTimeout(timer.current);
    if (data.onClosed) {
      data.onClosed();
    }
  }, [data.onClosed, timer.current]);

  useEffect(() => {
    if (!data.show) {
      return () => {};
    }
    const $modal = ref.current;
    const modal = BSModal.getOrCreateInstance($modal);
    $modal.addEventListener('hidden.bs.modal', onHidden);
    modal.show();
    if (data.delay > -1) {
      timer.current = setTimeout(() => modal.hide(), data.delay);
    }
    return () => $modal.removeEventListener('hidden.bs.modal', onHidden);
  }, [data.delay, data.show, onHidden, ref.current]);

  return (
    <div className={`fade modal ${className}`} data-backdrop={data.static ? 'static' : null} data-keyboard={!data.static} ref={ref} role="dialog">
      <div className="modal-dialog modal-md" role="document" style={data.width ? { maxWidth: data.width, width: data.width } : null}>
        <div className="modal-content">{header}{body}{footer}</div>
      </div>
    </div>
  );
})`
& {
  .modal-content {
    border-radius: 0.3rem;

    .modal-header {
      background-color: #f3f3f3;
      padding: 0.5rem 0.85rem;

      .modal-title {
        color: #333;
        padding: 0;
      }
      a.close {
        cursor: pointer;
        font-size: 1.5rem;
        text-decoration: none;
      }
    }
    .modal-body {
      text-align: center;
    }
    .modal-footer {
      padding: 0.5rem 0.75rem;

      .btn {
        padding: 5px 10px;

        &:not(:last-of-type) {
          margin-right: 5px;
        }
        &:hover {
          box-shadow: none;
        }
      }
      .btn-default {
        background-color: #e7e7e7;
        border-color: #ccc;
        color: #af1685;
        font-weight: 400;

        &:hover {
          color: #fff;
        }
      }
    }
  }
}
`;
