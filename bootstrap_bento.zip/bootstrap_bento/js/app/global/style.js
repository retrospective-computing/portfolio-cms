/*
 * NOTICE: (c) 2015 - 2021 ConsumerInfo.com, Inc, an Experian company.
 * All Rights Reserved.
 * The material contained herein is protected by copyright and trade secret law.
 * Unauthorized use, copying, or dissemination is strictly prohibited.
 * All material contained herein is subject to Experian's confidential
 * information policies.
 * -----------------------------------------------------------------------------
 */

import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
.form-type-bento-editable {
  min-height: 2.125rem;
}
`;
