// https://datatables.net/download/#bs5/dt-2.0.1/b-3.0.0/b-print-3.0.0/kt-2.12.0/r-3.0.0/rg-1.5.0/sc-2.4.0/sl-2.0.0
// Order Matters™!
// eslint-disable-next-line import/no-extraneous-dependencies
import $ from 'jquery';
import DataTable from 'datatables.net-bs5';
import 'datatables.net-buttons-bs5';
// eslint-disable-next-line import/no-extraneous-dependencies
import 'datatables.net-buttons/js/buttons.print';
import 'datatables.net-keytable-bs5';
import 'datatables.net-responsive-bs5';
import 'datatables.net-rowgroup-bs5';
import 'datatables.net-scroller-bs5';
import 'datatables.net-select-bs5';

DataTable.ajax = (opts) => $.extend(true, {}, DataTable.defaults.ajax, opts);
DataTable.clearPipeline = (dt) => dt.iterator('table', (settings) => (settings.clearCache = true));
DataTable.default = (opts) => $.extend(true, {}, DataTable.defaults, opts);

$.extend(true, DataTable.defaults, {
  ajax: {
    // Function or object with parameters to send to the server matching
    // how `ajax.data` works in DataTables.
    data: null,
    method: 'POST',
    // Number of pages to cache.
    pages: 2,
    url: '',
  },
  language: {
    emptyTable: 'Nothing found',
    info: 'Showing page _PAGE_ of _PAGES_',
    infoEmpty: 'No records available',
    infoFiltered: '(filtered from _MAX_ records)',
  },
  layout: {
    topStart: 'search',
    topEnd: 'buttons',
    bottomStart: ['pageLength', 'info'],
    bottomEnd: {
      paging: {
        type: 'full_numbers',
      },
    },
  },
  ordering: true,
  processing: true,
  responsive: true,
  serverSide: true,
  stateSave: true,
});

DataTable.pipeline = (opts) => {
  const cache = {
    json: null,
    lower: -1,
    request: null,
    upper: null,
  };
  const ajax = DataTable.ajax(opts);
  return (request, drawCallback, settings) => {
    let fetch = false;
    let requestStart = request.start;
    const drawStart = request.start;
    const requestLength = request.length;
    const requestEnd = requestStart + requestLength;

    if ($.isPlainObject(ajax.data) && ajax.data.columnOrder) {
      request.columns = JSON.parse(ajax.data.columnOrder);
    }

    request.timestamp = new Date().valueOf();

    if (settings.clearCache) {
      // Clear the cache.
      cache.json = null;
      cache.lower = -1;
      cache.request = null;
      cache.upper = null;
      fetch = true;
      settings.clearCache = false;
    } else if (cache.lower < 0 || requestStart < cache.lower || requestEnd > cache.upper) {
      // Outside cached data - need to make a request.
      fetch = true;
    } else if (JSON.stringify(request.order) !== JSON.stringify(cache.request.order)
      || JSON.stringify(request.columns) !== JSON.stringify(cache.request.columns)
      || JSON.stringify(request.search) !== JSON.stringify(cache.request.search)
    ) {
      // Properties changed (ordering, columns, searching).
      fetch = true;
    }

    // Store the request for checking next time around
    cache.request = $.extend(true, {}, request);

    if (fetch) {
      // Need data from the server
      if (requestStart < cache.lower) {
        requestStart -= requestLength * (ajax.pages - 1);
        // istanbul ignore else
        if (requestStart < 0) {
          requestStart = 0;
        }
      }

      cache.lower = requestStart;
      cache.upper = requestStart + (requestLength * ajax.pages);

      request.start = requestStart;
      request.length = requestLength * ajax.pages;

      // Provide the same `data` options as DataTables.
      // istanbul ignore else
      if ($.isFunction(ajax.data)) {
        // As a function it is executed with the data object as an arg
        // for manipulation. If an object is returned, it is used as the
        // data object to submit
        const d = ajax.data(request);
        // istanbul ignore else
        if (d) {
          $.extend(request, d);
        }
      } else if ($.isPlainObject(ajax.data)) {
        // As an object, the data given extends the default
        $.extend(request, ajax.data);
      }
      // istanbul ignore else
      if ($.isFunction(request.filters)) {
        request.filters(request);
      }

      delete request.columnOrder;

      settings.jqXHR = $.ajax({
        cache: false,
        contentType: 'application/json',
        data: JSON.stringify(request),
        dataType: 'json',
        method: ajax.method,
        url: ajax.url,
        success(result) {
          const json = DataTable.preSuccess(result);
          cache.json = $.extend(true, {}, json);
          const items = json.data;
          if (cache.lower !== drawStart) {
            items?.splice(0, drawStart - cache.lower);
          }
          // istanbul ignore else
          if (requestLength >= -1) {
            items?.splice(requestLength, items.length);
          }
          drawCallback(json);
          DataTable.postDraw(json);
        },
      });
    } else {
      const json = $.extend(true, {}, cache.json);
      json.draw = request.draw; // Update the echo for each response
      const items = json.data;
      items.splice(0, requestStart - cache.lower);
      items.splice(requestLength, items.length);
      drawCallback(json);
      DataTable.postDraw(json);
    }
  };
};

DataTable.postDraw = () => {};
DataTable.preSuccess = (result) => result || {};
window.DataTable = DataTable;
