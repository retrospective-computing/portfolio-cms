/*!
 * NOTICE: (c) 2015 - 2024 ConsumerInfo.com, Inc, an Experian company.
 * All Rights Reserved.
 * The material contained herein is protected by copyright and trade secret law.
 * Unauthorized use, copying, or dissemination is strictly prohibited.
 * All material contained herein is subject to Experian's confidential
 * information policies.
 * -----------------------------------------------------------------------------
 */

(($, bx) => {
  let $adminToolbar;
  let $adminTray;
  let $footer;
  let $header;
  let $highlighted;
  const htmlPattern = /<[^>]*>([\s\S]*)<\/[^>]*>|<[^>]*>/g;
  let $main;
  const placements = {
    AUTO: 'auto',
    BOTTOM: 'bottom',
    LEFT: 'left',
    RIGHT: 'right',
    TOP: 'top',
  };
  const unsafeUrlPattern = /[^\w.:/@?&=#%+~-]+/g;
  const $window = $(window);

  const bentoDialog = async (args = {}) => {
    args.delay = args.delay || -1;
    args.ico = args.type === 'confirm' ? 'warning' : args.type;
    let timer;
    const $modal = $('body > .bento.modal');
    const $cancel = $modal.find('.cancel');
    const $close = $modal.find('.modal-header a.close');
    const $footNote = $modal.find('.modal-footnote');
    const $input = $modal.find('.modal-input');
    const $modalFooter = $modal.find('.modal-footer');
    const $ok = $modal.find('.ok');
    const showListener = async (evt) => {
      let footer = args.delay === -1;
      footer = !!~'|confirm|input|modal|'.indexOf(`|${args.type}|`);
      $modal.find('.ico').hide();
      $modal.find(`.ico-${args.ico}`).show();
      // Overrides max-width when width is set.
      $modal.find('.modal-dialog').css({
        maxWidth: args.width || '',
        width: args.width || '',
      });
      // VC scan workaround.
      $modal.find('.modal-message').html(String(args.message));
      $modal.find('.modal-title').html(String(args.title));

      $close[args.type === 'modal' ? 'show' : 'hide']();

      if (args.type === 'input') {
        $input.val(args.value || '').show();
      } else {
        $input.hide();
      }

      if (footer) {
        $cancel.off('click');
        $modalFooter.show();

        if (args.type === 'modal') {
          $cancel.hide();
          $footNote.show().get(0).innerHTML = args.footer || '';
          $ok.off('click').hide();
        } else {
          $cancel[args.cancel ? 'show' : 'hide']();
          $footNote.hide();
          $ok.show().off('click');

          // istanbul ignore else
          if (args.callback) {
            $ok
              .off('click')
              .on('click', () => {
                clearTimeout(timer);
                args.callback(args.type === 'input' ? $input.val() : true);
              });
            // istanbul ignore else
            if (args.cancel && args.type === 'confirm') {
              $cancel
                .off('click')
                .on('click', () => {
                  clearTimeout(timer);
                  args.callback(false);
                });
            }
          }
        }
      } else {
        $modalFooter.hide();
      }
      if (args.onShow) {
        await args.onShow(evt);
      }
    };

    if ($modal.hasClass('show')) {
      await showListener({
        currentTarget: $modal.get(0),
        delegateTarget: $modal.get(0),
        target: $modal.get(0),
      });
    } else {
      // istanbul ignore else
      if (args.backdrop) {
        $modal.attr({
          'data-bs-backdrop': args.backdrop,
          'data-bs-keyboard': args.backdrop !== 'static',
        });
      }
      $modal
        .off('show.bs.modal')
        .off('shown.bs.modal')
        // Before show.
        .on('show.bs.modal', showListener)
        // After shown.
        .on('shown.bs.modal', () => {
          const $backdrop = $('body > .modal-backdrop');
          // istanbul ignore else
          if ($backdrop.length) {
            $backdrop.not(':last').remove();
          }
        });
      window.bootstrap.Modal.getOrCreateInstance($modal).show();
    }

    if (args.delay > -1) {
      timer = setTimeout(() => {
        window.bootstrap.Modal.getOrCreateInstance($modal).hide();
        // istanbul ignore else
        if (args.callback && args.type === 'confirm') {
          args.callback(false);
        }
      }, args.delay);
    }
  };

  const onResize = () => {
    const footerHeight = $footer.height() || 0;
    // footer .footer > ul > li.
    const footerPadding = 20;
    const headerHeight = $header.height() || 0;
    let containerHeight = $window.height() - (headerHeight + footerHeight + footerPadding);
    containerHeight -= $adminToolbar.height() || 0;
    containerHeight -= $adminTray.height() || 0;
    $main.css('min-height', containerHeight);
  };

  const ordinal = (value) => {
    let ord = 'th';
    if (value % 10 === 1 && value % 100 !== 11) {
      ord = 'st';
    } else if (value % 10 === 2 && value % 100 !== 12) {
      ord = 'nd';
    } else if (value % 10 === 3 && value % 100 !== 13) {
      ord = 'rd';
    }
    return `${value}${ord}`;
  };

  const queueInfo = (name) => new Promise((resolve) => {
    $.get(bx.bento_global.url(`/bento/queue/info/${name}`))
      .always((response) => resolve({
        count: response?.count || 0,
        title: response?.title || name,
      }));
  });

  const queueProcess = (name, lease) => new Promise((resolve) => {
    $.get(bx.bento_global.url(`/bento/queue/process/single/${name}/${lease}`))
      .always((response, status, reason) => {
        const error = response?.error
          || (status === 'error' ? reason : '')
          || ([200, 204].includes(response?.status || 200)
            ? '' : `Unknown error. Most likely because maximum execution time of ${lease} seconds exceeded.`);
        const success = response?.success;
        resolve({ error, success, remainder: response?.remainder || 0 });
      });
  });

  window.Drupal.behaviors.bento_global = {
    acronym(value) {
      // Babel/Jest/Testing lib workaround.
      return ((val) => val || '')(value?.match?.(/(?<=(\s|_|^))[a-z]/gi)?.join(''));
    },
    attach() {
      $(() => {
        // istanbul ignore else
        if ($.fn.tooltip) {
          // eslint-disable-next-line no-underscore-dangle
          $.fn.tooltip.Constructor.prototype
            ._getAttachment = (placement) => (placements[placement?.toUpperCase()] || 'auto');
        }
        $('span.system-error').prev('h1.page-header').css({ marginLeft: '20px' });
        $adminToolbar = $('#toolbar-bar');
        $adminTray = $('#toolbar-item-administration-tray');
        $footer = $('footer');
        $header = $('header');
        $highlighted = $('div.layout-container div.region.region-highlighted');
        $main = $('main');
        // istanbul ignore else
        if ($('#user-login-form').length && !$main.hasClass('login-form')) {
          // Found login form!
          $main.addClass('login-form');
        }
        if ($('#user-logout-confirm').length && !$main.hasClass('logout-form')) {
          // Found logout form!
          $main.addClass('logout-form');
        }
        onResize();
      });
      window.addEventListener('resize', onResize);
    },
    batch(config) {
      const footer = 'Please do not navigate away from this page.';
      bx.bento_global.modalDialog({
        backdrop: 'static',
        footer,
        message: `
          <div class="batch-modal">
            <h6 class="message">Processing your request...</h6>
            <div class="progress" role="progressbar">
              <div class="bg-success progress-bar progress-bar-animated progress-bar-striped" style="width: 0%">0%</div>
            </div>
          </div>
        `,
        onShow: async (evt) => {
          const $modal = $(evt.currentTarget);
          // After $modal assignment.
          const $close = $modal.find('.modal-header a.close').hide();
          const $container = $modal.find('.modal-message .batch-modal');
          const errors = [];
          const successes = [];
          const $footNote = $modal.find('.modal-footnote');
          const $message = $container.find('.message');
          let percentage = 0;
          let processed = 0;
          const $progress = $container.find('.progress .progress-bar');
          // istanbul ignore else
          if (Array.isArray(config?.queues)) {
            const max = Math.floor(100 / config.queues.length);
            await window.sequential(config.queues, async (queue, index) => {
              const { lease, name } = queue;
              const { count, title } = await queueInfo(name);
              processed += count;
              let remainder = count;
              const slice = max / count;
              await window.sequential(Array.from(Array(count)), async (_, idx) => {
                let error = '';
                let success = '';
                $message.html(`Processing <b>${queue?.title || title}</b>: ${remainder} item${remainder > 1 ? 's' : ''} remaining...`);
                ({ error, success, remainder } = await queueProcess(name, lease));
                percentage += slice;
                $progress.css('width', `${percentage}%`).text(`${Math.floor(percentage)}%`);
                if (error) {
                  errors.push(`<b>${queue?.title || title}</b> ${ordinal(idx + 1)} item encountered problem: ${error}`);
                  $footNote.html(`<ul>${errors.map((msg) => `<li class="text-danger">${msg}</li>`).join('')}</ul>${footer}`);
                }
                if (success) {
                  successes.push(`<b>${queue?.title || title}</b> ${ordinal(idx + 1)} item processed with message: ${success}`);
                  $footNote.html(`<ul>${successes.map((msg) => `<li class="text-success">${msg}</li>`).join('')}</ul>${footer}`);
                }
              });
              percentage = (index + 1) * max;
              $progress.css('width', `${percentage}%`).text(`${Math.floor(percentage)}%`);
            });
          }
          percentage = 100;
          if (errors.length) {
            $progress
              .removeClass('bg-success')
              .addClass(errors.length === processed ? 'bg-danger' : 'bg-warning');
          }
          $progress.css('width', `${percentage}%`).text(`${percentage}%`);
          await window.sleep(500);
          $message.html('Your request has been processed.');
          if (errors.length) {
            $footNote.html(`<ul>${errors.map((msg) => `<li class="text-danger">${msg}</li>`).join('')}</ul>`);
          } else if (successes.length) {
            $footNote.html(`<ul>${successes.map((msg) => `<li class="text-success">${msg}</li>`).join('')}</ul>`);
          } else {
            $footNote.hide();
          }
          $close.show();
        },
        title: config.title,
        width: '75%',
      });
    },
    bentoDialog,
    browser: {
      firefox: navigator.userAgent.includes('Firefox'),
    },
    callbackConfirmDialog(config) {
      bx.bento_global.confirmDialog(
        config?.confirm?.title,
        config?.confirm?.message,
        async (confirmed) => {
          // istanbul ignore else
          if (confirmed) {
            // Allow the system the breath.
            await window.sleep(100);
            await bx.bento_global.callbackDialog({
              callback: config?.callback,
              inflight: config?.inflight,
            });
          }
        },
      );
    },
    async callbackDialog(config) {
      bx.bento_global.notifyDialog(
        'info',
        config?.inflight?.title,
        config?.inflight?.message,
      );
      // Allow people to read the message.
      await window.sleep(500);
      config?.callback?.();
    },
    confirmDialog(title, message, callback) {
      bx.bento_global.bentoDialog({
        callback,
        cancel: true,
        message,
        title,
        type: 'confirm',
      });
    },
    dateTimeFormat: 'MM/dd/yyyy hh:mm:ss a z',
    debounce(func, delay) {
      let timer;
      const debounced = (...args) => {
        clearTimeout(timer);
        timer = setTimeout(async () => {
          await func(...args);
        }, delay);
      };
      debounced.cancel = () => {
        // istanbul ignore else
        if (timer) {
          clearTimeout(timer);
          timer = null;
        }
      };
      return debounced;
    },
    defaultTimeZone: 'America/Los_Angeles',
    detach() {
      window.removeEventListener('resize', onResize);
    },
    displayError(response) {
      const errors = (response?.['messenger.error'] || []).slice();
      // istanbul ignore else
      if (response?.error) {
        errors.unshift(response.error);
      }
      const { length } = errors;
      // istanbul ignore else
      if (length) {
        let message = '';
        if (length === 1) {
          message = `<p>${errors[0]}</p>`;
        } else {
          message = errors.map((error) => `<li class="item item--message">${error}</li>`).join('');
          message = `<ul class="item-list item-list--messages">${message}</ul>`;
        }
        $highlighted.find('div[data-drupal-messages]').remove();
        // VC scan workaround.
        $highlighted.append(String(`
          <div data-drupal-messages="">
            <div class="messages__wrapper">
              <div aria-label="Error message" class="alert alert-danger alert-dismissible" role="alert">
                <button aria-label="Close" class="btn close" data-bs-dismiss="alert" role="button" type="button"><span aria-hidden="true">×</span></button>
                <h2 class="sr-only">Error message</h2>
                ${message}
              </div>
            </div>
          </div>
        `));
      }
    },
    downloadFile(data, name, ext) {
      const anchor = document.createElement('a');
      anchor.download = `${name}-${new Date().toISOString().replace(/[-:.TZ]/g, '')}.${ext}`;
      anchor.href = `data:application/json;base64,${btoa(unescape(encodeURIComponent(data)))}`;
      anchor.click();
    },
    jsonValue(text, path = '@') {
      return window.jmespath.search(bx.bento_global.parseJson(text), path);
    },
    message(message, data) {
      if (/data-drupal-selector="user-login-form"/.test(data?.responseText || data)) {
        return `${message}: session expired. Please re-login.`;
      }
      return message;
    },
    modalDialog({
      backdrop = true,
      footer = '',
      message = '',
      onShow = () => {},
      title = '',
      width = '',
    }) {
      bx.bento_global.bentoDialog({
        backdrop,
        footer,
        message,
        onShow,
        title,
        type: 'modal',
        width,
      });
    },
    notifyDialog(type, title, message, delay = -1, backdrop = true) {
      bx.bento_global.bentoDialog({
        backdrop,
        delay,
        message,
        title,
        type,
      });
    },
    parseJson(value) {
      let response = value;
      try {
        response = JSON.parse(value);
      } catch {
        // no-op.
      }
      return response;
    },
    promptDialog(title, message, value, callback) {
      bx.bento_global.bentoDialog({
        callback,
        cancel: true,
        message,
        title,
        type: 'input',
        value,
      });
    },
    queries(value) {
      return typeof (value) === 'string' && value.length ? value.substring(1).split('&').reduce((accumulator, entry) => {
        const [key, val] = entry.split('=');
        accumulator[decodeURIComponent(key)] = decodeURIComponent(val);
        return accumulator;
      }, {}) : {};
    },
    reformat(value) {
      let parsed = value;
      try {
        if (typeof (value) === 'string') {
          parsed = JSON.parse(value || '{}');
        }
      } catch {
        // no-op.
      }
      return typeof (parsed) === 'string' ? parsed : JSON.stringify(parsed, null, 4);
    },
    sanitize(value) {
      return typeof (value) === 'string' ? value.replace(htmlPattern, '') : '';
    },
    sanitizeUrl(value) {
      let response = '';
      try {
        if (typeof (value) === 'string') {
          response = decodeURIComponent(value).replace(htmlPattern, '').replace(unsafeUrlPattern, '');
        }
      } catch {
        // no-op.
      }
      return response;
    },
    setHash(values) {
      if (values?.constructor === Object) {
        window.location.hash = Object.entries(values).map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`).join('&');
      }
    },
    titleCase(value) {
      return String(value).toLowerCase().replace(/\b\w/g, (str) => str.toUpperCase());
    },
    url(path) {
      return /^javascript:/.test(path) ? path : `${window.drupalSettings.path.baseUrl}${path}`.replace('//', '/');
    },
  };
})(window.jQuery, window.Drupal.behaviors);
