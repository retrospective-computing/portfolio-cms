/*
 * NOTICE: (c) 2015 - 2023 ConsumerInfo.com, Inc, an Experian company.
 * All Rights Reserved.
 * The material contained herein is protected by copyright and trade secret law.
 * Unauthorized use, copying, or dissemination is strictly prohibited.
 * All material contained herein is subject to Experian's confidential
 * information policies.
 * -----------------------------------------------------------------------------
 */

require('jquery-ui/ui/widget');
require('jquery-ui/ui/widgets/mouse');
require('jquery-ui/ui/widgets/sortable');
