/*
 * NOTICE: (c) 2015 - 2024 ConsumerInfo.com, Inc, an Experian company.
 * All Rights Reserved.
 * The material contained herein is protected by copyright and trade secret law.
 * Unauthorized use, copying, or dissemination is strictly prohibited.
 * All material contained herein is subject to Experian's confidential
 * information policies.
 * -----------------------------------------------------------------------------
 */

import {
  isBefore,
  isValid,
  parse,
  parseISO,
} from 'date-fns';
import { formatInTimeZone } from 'date-fns-tz';

((bx) => {
  const { dateTimeFormat, defaultTimeZone } = bx.bento_global;
  window.Drupal.behaviors.bento_datetime = {
    date(value, options) {
      const parsed = bx.bento_datetime.parseDate(value, options?.from);
      return isValid(parsed) ? bx.bento_datetime.format(parsed, options?.to) : '';
    },
    format(value, to) {
      return formatInTimeZone(value, defaultTimeZone, to || dateTimeFormat);
    },
    isBeyond(value, from) {
      const parsed = bx.bento_datetime.parseDate(value, from);
      return isValid(parsed) ? !isBefore(new Date(), parsed) : true;
    },
    parseDate(value, from) {
      return (from || dateTimeFormat).toUpperCase() === 'ISO'
        ? parseISO(value, new Date())
        : (
          // istanbul ignore next
          // eslint-disable-next-line no-constant-binary-expression
          new Date(value) || parse(
            value,
            // istanbul ignore next
            from || dateTimeFormat,
            new Date(),
          )
        );
    },
    timeConstraint(offset = 15) {
      const response = new Date();
      const minutes = response.getMinutes();
      response.setMinutes(minutes + (offset - (minutes % offset)));
      response.setSeconds(0);
      return bx.bento_datetime.format(response);
    },
  };
})(window.Drupal.behaviors);
